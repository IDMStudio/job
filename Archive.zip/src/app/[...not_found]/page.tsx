import ErrorPageArea from "../components/error/error-page-area";


export default function NotFound() {
  return (
    <div>
      <ErrorPageArea/>
    </div>
  );
}
